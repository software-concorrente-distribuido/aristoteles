

var caixaOcupado = false;
var filaDoCaixa = [];

function Caixa(clienteAtual) {
    
    if (caixaOcupado) {
        
        return;
    }

    caixaOcupado = true;

    console.log(`O cliente de id ${clienteAtual.id} entrou para ser atendido pelo caixa e comprará ${clienteAtual.numeroItensNoCarrinho} itens`);

    setTimeout(() => {
        console.log(`O cliente de id ${clienteAtual.id} finalizou sua compra com a duração de ${clienteAtual.numeroItensNoCarrinho * 100} milisegundos`);
        
        caixaOcupado = false;
        filaDoCaixa.shift();
        
        if (filaDoCaixa.length != 0) {
            console.log(filaDoCaixa);
            Caixa(filaDoCaixa[0]);
        }

    }, clienteAtual.numeroItensNoCarrinho * 100);
}

function Inicializar() {

    var numClientes = Math.floor(Math.random() * 20) + 1;
    console.log(`Vão ser criados ${numClientes} clientes`);

    const clientes = criarClientes(numClientes);

    clientes.sort(function(a, b) {
        return b.sorte - a.sorte;
    });

    filaDoCaixa = [...clientes];
    
    for (let i = 0; i < filaDoCaixa.length; i++) {
        setTimeout(() => {
            Caixa(filaDoCaixa[i]);
        }, filaDoCaixa[i].numeroItensNoCarrinho * 100)
    }

};

function criarClientes(numClientes) {

    var clientes = [];

    for (let i = 0; i < numClientes; i++) {

        const cliente = {
            id: i,
            numeroItensNoCarrinho: Math.floor(Math.random() * 40) + 1,
            sorte: Math.floor(Math.random() * 100) + 1,
        };

        clientes.push(cliente);
    }
    console.log('Clientes criados:');
    console.log(clientes);

    return clientes;
}

Inicializar();