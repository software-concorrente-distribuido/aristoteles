import threading
import time

last_id = 0

lock = threading.Lock()

def generate_id():
    global last_id
    for _ in range(10):
        time.sleep(0.1)
        
        lock.acquire()
        print(f"Thread {threading.current_thread().name}: Último ID visto: {last_id}")
        
        time.sleep(0.1)
        
        last_id += 1
        print(f"Thread {threading.current_thread().name}: Gerou ID {last_id}")
        
        lock.release()

if __name__ == "__main__":
    thread1 = threading.Thread(target=generate_id, name="Thread 1")
    thread2 = threading.Thread(target=generate_id, name="Thread 2")

    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()

    print("Último ID gerado:", last_id)
