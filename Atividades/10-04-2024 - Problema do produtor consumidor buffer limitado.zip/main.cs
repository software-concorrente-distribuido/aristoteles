using System;
using System.Threading;

class Program
{
    static SemaphoreSlim semaphoreFull;
    static SemaphoreSlim semaphoreEmpty;
    static Mutex mutex;
    static int[] buffer;
    static int bufferSize;
    static int itemCount;
    static Random random = new Random();

    static void Main(string[] args)
    {
        bufferSize = 5; // Tamanho do buffer
        itemCount = 0; // Quantidade atual de itens no buffer
        buffer = new int[bufferSize];
        semaphoreFull = new SemaphoreSlim(0, bufferSize);
        semaphoreEmpty = new SemaphoreSlim(bufferSize, bufferSize);
        mutex = new Mutex();

        Thread producerThread = new Thread(Producer);
        Thread consumerThread = new Thread(Consumer);

        producerThread.Start();
        consumerThread.Start();

        producerThread.Join();
        consumerThread.Join();
    }

    static void Producer()
    {
        for (int i = 0; i < 10; i++)
        {
            int item = random.Next(1000); // Produz um item
            semaphoreEmpty.Wait(); // Espera até que haja espaço disponível no buffer
            mutex.WaitOne(); // Garante exclusão mútua no acesso ao buffer
            buffer[itemCount] = item; // Coloca o item no buffer
            itemCount++;
            Console.WriteLine($"Produzido: {item}");
            mutex.ReleaseMutex(); // Libera o mutex
            semaphoreFull.Release(); // Sinaliza que há um item disponível para consumo
            Thread.Sleep(random.Next(1000)); // Simula um tempo de produção variável
        }
    }

    static void Consumer()
    {
        for (int i = 0; i < 10; i++)
        {
            semaphoreFull.Wait(); // Espera até que haja itens disponíveis no buffer
            mutex.WaitOne(); // Garante exclusão mútua no acesso ao buffer
            int item = buffer[itemCount - 1]; // Remove o último item do buffer
            itemCount--;
            Console.WriteLine($"Consumido: {item}");
            mutex.ReleaseMutex(); // Libera o mutex
            semaphoreEmpty.Release(); // Sinaliza que há espaço disponível para produção
            Thread.Sleep(random.Next(1000)); // Simula um tempo de consumo variável
        }
    }
}