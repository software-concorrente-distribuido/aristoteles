using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

class Program
{
    static SemaphoreSlim semaphore = new SemaphoreSlim(1);

    static void Main()
    {
        Thread cpfThread = new Thread(ValidarCPF);
        Thread ordenacaoThread = new Thread(OrdenarNumeros);
        Thread calculoThread = new Thread(RealizarCalculos);

        cpfThread.Start();
        ordenacaoThread.Start();
        calculoThread.Start();

        cpfThread.Join();
        ordenacaoThread.Join();
        calculoThread.Join();

        Console.WriteLine("***Todas as operações foram concluídas***");
    }

    static void ValidarCPF()
    {
        semaphore.Wait();

        Console.WriteLine("===Iniciando validação de CPF===");

        string cpf = "123.456.789-09";
        bool cpfValido = ValidarCPF(cpf);

        Console.WriteLine($"CPF {cpf} é válido? {cpfValido}");

        semaphore.Release();
        
        Console.WriteLine("===Finalizando validação de CPF===");
    }

    static bool ValidarCPF(string cpf)
    {

        return cpf.Length == 14 && cpf.All(char.IsDigit);
    }

    static void OrdenarNumeros()
    {
        semaphore.Wait();

        Console.WriteLine("===Iniciando ordenação de números===");

        int[] numeros = { 5, 2, 8, 1, 3 };
        Array.Sort(numeros);

        Console.WriteLine("Números ordenados: " + string.Join(", ", numeros));

        semaphore.Release();
        
        Console.WriteLine("===Finalizando ordenação de números===");
    }

    static void RealizarCalculos()
    {
        semaphore.Wait();

        Console.WriteLine("===Iniciando cálculos matemáticos===");

        int resultado = 2 + 2 * 2 - 4 / 2;

        Console.WriteLine($"Resultado dos cálculos: {resultado}");

        semaphore.Release();
        
        Console.WriteLine("===Finalizando cálculos matemáticos===");
    }
}