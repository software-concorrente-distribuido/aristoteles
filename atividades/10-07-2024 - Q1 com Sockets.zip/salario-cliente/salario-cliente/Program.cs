﻿using System;
using System.Net.Sockets;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        // Define o IP e a porta do servidor
        string serverIp = "127.0.0.1";
        int port = 13000;

        // Conecta ao servidor
        TcpClient client = new TcpClient(serverIp, port);
        NetworkStream stream = client.GetStream();

        // Solicita os dados do funcionário
        Console.WriteLine("Digite o nome do funcionário:");
        string nome = Console.ReadLine();
        Console.WriteLine("Digite o cargo do funcionário:");
        string cargo = Console.ReadLine();
        Console.WriteLine("Digite o salário do funcionário:");
        double salario = double.Parse(Console.ReadLine());

        // Envia os dados para o servidor
        string dataToSend = $"{nome};{cargo};{salario}";
        byte[] data = Encoding.UTF8.GetBytes(dataToSend);
        stream.Write(data, 0, data.Length);

        // Lê a resposta do servidor
        byte[] buffer = new byte[1024];
        int bytesRead = stream.Read(buffer, 0, buffer.Length);
        string receivedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);

        // Processa e exibe a resposta
        string[] parts = receivedData.Split(';');
        string nomeRecebido = parts[0];
        double salarioReajustado = double.Parse(parts[1]);
        Console.WriteLine($"Nome: {nomeRecebido}, Salário Reajustado: {salarioReajustado:F2}");

        // Fecha a conexão
        client.Close();
    }
}
