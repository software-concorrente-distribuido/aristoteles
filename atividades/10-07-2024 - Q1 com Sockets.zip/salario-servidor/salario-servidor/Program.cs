﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        // Define o IP e a porta para o servidor
        IPAddress ip = IPAddress.Parse("127.0.0.1");
        int port = 13000;
        TcpListener server = new TcpListener(ip, port);

        // Inicia o servidor
        server.Start();
        Console.WriteLine("Servidor iniciado...");

        while (true)
        {
            // Aguarda uma conexão de cliente
            TcpClient client = server.AcceptTcpClient();
            Console.WriteLine("Cliente conectado...");

            // Lê os dados enviados pelo cliente
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            string receivedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);

            // Processa os dados recebidos
            string[] parts = receivedData.Split(';');
            string nome = parts[0];
            string cargo = parts[1];
            double salario = double.Parse(parts[2]);
            double salarioReajustado = salario;

            if (cargo.ToLower() == "operador")
            {
                salarioReajustado = salario * 1.20;
            }
            else if (cargo.ToLower() == "programador")
            {
                salarioReajustado = salario * 1.18;
            }

            // Envia a resposta para o cliente
            string response = $"{nome};{salarioReajustado:F2}";
            byte[] responseData = Encoding.UTF8.GetBytes(response);
            stream.Write(responseData, 0, responseData.Length);

            // Fecha a conexão com o cliente
            client.Close();
        }
    }
}